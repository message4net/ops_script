<?php session_start();
$htmlArr[pgno]=$_POST[pgno];
$htmlArr[id]=$_POST[id];
$jsonArr=json_encode($htmlArr);
echo $jsonArr;
?>
