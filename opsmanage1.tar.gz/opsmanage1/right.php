<?php
switch ($_GET[fnctn]){
case 'info':
	require_once('info.php');
	break;
case 'serviceop':
	require_once('serviceop.php');
//	require_once('test.php');
	break;
}
?>
