<?php session_start();
//var_dump($_POST[lid]);
$navmenuID=$_POST[lid];
require_once('config.inc.php');
require_once IncludePath.'db.inc.php';
$dbint=new DBSql();
$dataNavmenuID=$dbint->select("select * from link_js where id=".$navmenuID);
//$htmlArr[id]=$navmenuID;
//$jsonArr=json_encode($htmlArr);
//echo $jsonArr;
//unset($htmlArr);
require_once ModelPath.$dataNavmenuID[0][url];
?>
