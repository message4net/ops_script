<?php
echo 9-8%3;
//$a=1;
//echo 1;
//var_dump(json_encode($_POST[tmpdata]));
//var_dump($_POST);
//$a=1;
//echo 1;
//$tArr=array(
//	'1'=>array(
//		'id'=>1,
//		'name'=>'新增'
//	),
//	'2'=>array(
//		'id'=>2,
//		'name'=>'修改'
//	),
//	'3'=>array(
//		'id'=>3,
//		'name'=>'删除'
//	)
//);
//var_dump($tArr);
//foreach($_SERVER as $key=>$val)
//	echo $key.'->'.$val.'<br/>';
//define("mP","123");
//a=45
//echo mP.$a;
//$arr=array();
//$arr[id]=$a;
////var_dump($arr);
////var_dump($a);
////echo $a;
//echo 'abceedd'
?>
