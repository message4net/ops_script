<?php
require_once IncludePath.'dfn.inc.php';
require_once IncludePath.'vrf.inc.php';
require_once IncludePath.'op.inc.php';
$strvrf=new strvrf();
$dfnvar=new dfnvar();
$svcop=new svcOp();
$dataOp=$dbint->select('select * from op_service where id='.$_GET[cid]);
$dataOpNm=$dbint->select('select * from service_info where id='.$dataOp[0][service_id]);
$dataOpId=$dbint->select('select * from op_service where service_id='.$dataOp[0][service_id]);
$dataOpOptn=$dbint->select('select * from wordbook where relation_id=28');
$optnarray=$dfnvar->StrctRflctArr($dataOpOptn,'varname');
if(!empty($dataOpNm[0][feature_pro])){
	$proNo=$svcop->proVrf($dataOpNm,$dataOp);
	if($proNo[0]==1){
		$status_svc='开启';
	}elseif($proNo[0]==0){
		$status_svc='<p style="color:red">关闭</p>';
	}else{
		$status_svc='异常';
	}
}
?>
<div><b><i>位置:服务管理->维护信息->维护</i></b></div>
<!--
<div><table><tr><th>服务名称</th><th>状态</th><th>维护选项</th><th rowspan='2'><button id='btn' type='button' onclick='showHint(&quot;serviceop_deal.php&quot;,&quot;txtHint&quot;)'>点击执行</button></th></tr>
-->
<div><table><tr><th>服务名称</th><th>状态</th><th>维护选项</th><th rowspan='2'><button id='btn' type='button'>点击执行</button></th></tr>
	<tr><td><?php echo $dataOpNm[0][game_server_name]; ?></td>
		<td id='r2c2'><?php echo $status_svc; ?></td>
		<td><select name='op_op_id'>
		<?php foreach($dataOpId as $key=>$val){ ?>
		<option value='
<?php
if($dataOp[0][op_op_id]==$val[op_op_id]){
        echo $val[op_op_id];
?>' selected='selected
<?php
}else{
        echo $val[op_op_id];} ?>'>
<?php echo $optnarray[$val[op_op_id]][varvalue]; ?></option>
                <?php } ?>
                </select></td></tr>
</table></div>
<div id='txtHint'></div>
<!--
<script type="text/javascript" src="jquery-1.11.3.min.js"></script>
-->
<script type="text/javascript">
$(document).ready(function(){
//	$("#btn").click(function(){
//	alert($("select[name='op_op_id'] option:selected").val());
//	});
  $("#btn").click(function(){
	$.ajax({
	type:"POST",
	url:"serviceop_deal.php",
	data:{opname:'<?php echo json_encode($dataOpNm);?>',opdetail:$("select[name='op_op_id'] option:selected").val()},
	beforeSend:function(){
		$('#btn').attr({"disabled":"disabled"});
		$('#txtHint').html('<p style="color:red">处理中，请耐心等候此处处理结果。。。</p>');
		},
	success: function(data){
//var t=eval(data);
//alert(t[1]);
	$('#txtHint').text(data);
		},
	complete:function(){
		$('#btn').removeAttr("disabled");
		}
	});
  });
});
//#########split###########
//$(document).ready(function(){
//  $("#btn").click(function(){
//  $('#txtHint').load('test4.php');
//  });
//});
//#########split###########
//function showHint(url,elmntId)
//{
//var xmlhttp;
//var urla='a=<?php echo json_encode($dataOpNm); ?>';
//if (window.XMLHttpRequest)
//  {// code for IE7+, Firefox, Chrome, Opera, Safari
//  xmlhttp=new XMLHttpRequest();
//  }
//else
//  {// code for IE6, IE5
//  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
//  }
//xmlhttp.onreadystatechange=function()
//  {
//  if (xmlhttp.readyState==4 && xmlhttp.status==200)
//    {
//    document.getElementById(elmntId).innerHTML=xmlhttp.responseText;
//    }
//  }
//xmlhttp.open("POST",url,true);
//xmlhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
//xmlhttp.send(urla);
//}
</script>
<!--
<div id='txtHint'></div>
<script type="text/javascript">
function showHint(url,elmntId)
{
var xmlhttp;
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById(elmntId).innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET",url,true);
xmlhttp.send();
}
</script>
-->
