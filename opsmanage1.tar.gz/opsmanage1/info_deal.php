<?php session_start();
require_once('config.inc.php');
require_once IncludePath.'dfn.inc.php';
require_once IncludePath.'vrf.inc.php';
require_once IncludePath.'db.inc.php';
$dbint1=new DBSql();
$dfnvar1=new dfnvar();
$strvrf1=new strvrf();
switch ($_GET[mid]){
case '18':
case '20':
case '17':
	$dealTable='op_service';
	break;
case '11':
case '12':
case '10':
	$dealTable='service_info';
	break;
case '24':
case '25':
case '26':
	$dealTable='server_info';
	break;
}
is_null($_GET[pgnm]) ? $sfxUrl='&pgnm=1' : $sfxUrl='&pgnm='.$_GET[pgnm];
$dataMenuR=$dbint1->select("select * from menu where relation_id=".$_GET[mid]);
$dataMenuId=$dbint1->select("select * from menu where id=".$_GET[mid]);
$dataRelationId=$dbint1->select("select * from menu where id=".$dataMenuId[0][relation_id]);
if($dataMenuId[0][function_id]==2||$dataMenuId[0][function_id]==3){
	$dataDealList=$dbint1->select("select * from wordbook where menu_id=".$dataRelationId[0][relation_id]);
	$dataVrf=$dbint1->select('select * from wordbook where remark like \'*%\' and menu_id='.$dataRelationId[0][relation_id]);
	foreach($dataVrf as $val){
	        $vrfarray[]=$_POST[$val[varname]];
	}
	if($strvrf1->StrNullVrf($vrfarray)==0){
	        $strvrf1->DfnErrMsg('处理失败，带*项有空，请确认');
		if(!empty($_GET[cid])){
	        	header("location:".$dataRelationId[0][url].'&cid='.$_GET[cid].$sfxUrl);
		}else{
	        	header("location:".$dataRelationId[0][url].$sfxUrl);
		}
		exit;
	}

}
switch ($dataMenuId[0][function_id]){
case '2':
	foreach($dataDealList as $val){
		if($val[name]=='id'){
			if(!is_null($_POST[$val[varname]])){
				$strvrf1->DfnErrMsg('新增记录时id不能有数值，若为已新增记录后再次新增新纪录，请清空id数值;否则异常，请联系管理员');
				header("location:".$dataRelationId[0][url].$sfxUrl."&cid=".$data[0][cid]);
			}
		}else{
			$sql1.=$val[varname].',';
			$sql2.='\''.$_POST[$val[varname]].'\',';
		}
	}
	$sql1=substr($sql1,0,strlen($sql1)-1);
	$sql2=substr($sql2,0,strlen($sql2)-1);
	$sql='insert into '.$dealTable.' ('.$sql1.') values('.$sql2.')';
	$dbint1->insert($sql);
	$data=$dbint1->select('select last_insert_id() as cid;');
	$strvrf1->DfnErrMsg('新增成功');
	header("location:".$dataRelationId[0][url].$sfxUrl."&cid=".$data[0][cid]);
	break;
case '3':
	foreach($dataDealList as $val){
		if($val[varname]=='id'){
			continue;
		}else{
			$sql1.=$val[varname].'=\''.$_POST[$val[varname]].'\',';
		}
	}
	$sql1=substr($sql1,0,strlen($sql1)-1);
	$sql='update '.$dealTable.' set '.$sql1.' where id=\''.$_GET[cid].'\'';
	$dbint1->update($sql);
	$strvrf1->DfnErrMsg('修改成功');
	header("location:".$dataRelationId[0][url].'&cid='.$_GET[cid].$sfxUrl);
	break;
case '4':
	$dbint1->delete('delete from '.$dealTable.' where id='.$_GET[cid]);
	$strvrf1->DfnErrMsg('删除成功');
	header("location:".$dataRelationId[0][url].'&cid='.$_GET[cid].$sfxUrl);
	break;
}
?>
