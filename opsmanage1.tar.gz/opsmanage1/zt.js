//$.extend({
//        aa:function(){
//          $(document).ready(function(){return 'aa';});
//        }
//});
//$.extend({
//        ab:function(){
//	var z=$.aa();
//          $(document).ready(function(){alert(z);});
//        }
//});
//
//
//
//$.extend({
//        aa:function(){
////          $(document).ready(function(){var z="[{'id':'1'},{'name':'a'}]";alert(z);});
//          $(document).ready(function(){var z='{"id":"1","name":"a"}';y==eval(z);
//		alert(y);});
////          $(document).ready(function(){var z=jQuery.parseJSON('{"id":"1","name":"a"}');alert(z.id);});
//        }
//});
//$.extend({
//        ab:function(){
//	var m=$.aa().value;
//	alert(m);
//        }
//});
