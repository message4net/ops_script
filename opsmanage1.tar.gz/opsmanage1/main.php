<?php
	$dbint=new DBSql();
	$datamenu=$dbint->select("select * from link_js where relation_id=0");
?>
<div id='infobar'>
	<div class='lft'>运维系统</div>
	<div id='typeflag' ltype='logout' class='rt'>
<?php
	if(isset($_SESSION[username]))
	        echo "欢迎".$_SESSION[username].",<a href='javascript:void(0);'>点此注销</a>";
?>
	</div>
</div>
<div id='navbar'>
	<div id='typeflag' ltype='<?php echo $datamenu[0][linktype];?>'><ul>
<?php
	foreach($datamenu as $val){
?>
		<li><a lid='<?php echo $val[id];?>' href='javascript:void(0);'><?php echo $val[name];?></a>&nbsp;&nbsp;&nbsp;&nbsp;|</li>
<?php
	}
?>
	</ul></div>
</div>
<div id='main'>
	<div id='main_lft' class='lft'></div>
	<div id='main_rt' class='rt'>
		<div id='pos_tip'></div>
		<div id='err_msg'></div>
		<div id='func_bar'></div>
		<div id='content_main' class='cntnt'></div>
	</div>
<div id='hidecontent' style='display:none' pgno='1' lid=''></div>
</div>
<script type="text/javascript">
$.view();
</script>
