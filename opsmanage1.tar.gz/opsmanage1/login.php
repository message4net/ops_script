<?php 
require_once IncludePath.'dfn.inc.php';
require_once IncludePath.'vrf.inc.php';
if(!isset($_SESSION[islogin]))
        $_SESSION[islogin]='NO';
if(!isset($_SESSION[loginduration]))
        $_SESSION[loginduration]=time()+28800;
$ssnarr=array($_SESSION['username'],$_SESSION['userpassword']);
$pstarr=array($_POST['username'],$_POST['userpassword']);
$strvrf=new strvrf();
$dbint=new DBSql();
if($strvrf->StrEqVrf($_SESSION[islogin],'NO')==1 || $_SESSION[loginduration]<time()){
	$tblarr=array(array('用户名','username','text'),array('密码','userpassword','password'));
	$htmlarr=array(array('id','login'));
	$dfnvar=new dfnvar();
	$dfnvar->StrctTblCrtStrt('请根据下方表格内容执行操作','index.php',$htmlarr);
	$dfnvar->StrctIpt($tblarr);
//	$dfnvar->StrctTblEnd('Crt', '登录');
	$htmlStr=$dfnvar->StrctTblEnd('Crt', '登录');
echo $htmlStr;
	$strvrf->PrntErrMsg($_SESSION['errmsg']);
}
if($strvrf->StrNullVrf($pstarr)==1){
	$data=$dbint->select('select * from user where name=\''.$_POST['username'].'\' and password=\''.$_POST['userpassword'].'\'');
	if(count($data)!==1) {
		if(count($data)>1)
			$strvrf->DfnErrMsg("用户名异常，请联系管理员");
		else 
			$strvrf->DfnErrMsg('用户名或密码输入错误，请重新输入');
		header("location:".BsUrl."index.php");
	}else{
		$_SESSION['username']=$_POST['username'];$_SESSION['userpassword']=$_POST['userpassword'];$_SESSION['userid']=$data[0]['id'];$_SESSION[islogin]='YES';
		header("location:".BsUrl."index.php");
	}
}
?>
