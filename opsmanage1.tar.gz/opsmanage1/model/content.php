<?php
//require '../config.inc.php';
//require '../inc/db.inc.php';
//$dbint=new DBSql();
//$navmenuID=4;
//$_POST[pgno]=1;
//测试分割线
require_once IncludePath.DfnInc;
require_once IncludePath.VrfInc;
require_once IncludePath.TipsgenFnc;
$strvrf=new strvrf();
$dfnvar=new dfnvar();
require_once ModelPath.InfoshowMdl;
?>
