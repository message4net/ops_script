<?php
//require '../config.inc.php';
//require '../inc/db.inc.php';
//$dbint=new DBSql();
//$navmenuID=1;
$dataRNavmenuID=$dbint->select("select * from link_js where relation_id=".$navmenuID);
$returnHtml="<div id='typeflag' ltype='".$dataRNavmenuID[0][linktype]."'><ul>";
foreach($dataRNavmenuID as $val){
	$returnHtml.="<li><a lid='".$val[id]."' href='javascript:void(0);'>".$val[name]."</a></li>";
}
$returnHtml.="</ul></div>";
$htmlArr=array();
$htmlArr[main_lft]=$returnHtml;
$jsonArr=json_encode($htmlArr);
echo $jsonArr;
unset($htmlArr);
?>
