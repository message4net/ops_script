<?php
session_destroy();
session_start();
require_once '/usr/local/http/opsmanage1/config.inc.php';
$_SESSION[islogin]="NO";
header("location:".BsUrl."index.php");
?>
