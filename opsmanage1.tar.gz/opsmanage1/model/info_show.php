<?php
$htmlArr=array();
$pageNO=$_POST[pgno];
$dataTmpC=$dbint->select("select * from link_js where id=".$navmenuID);
$dataMenuR=$dbint->select("select * from link_js where relation_id=".$navmenuID);
$posTips=genTips($dataTmpC,$dataTmpC[0][name]);
$htmlArr[pos_tip]=$posTips;
$errMsg=$strvrf->PrntErrMsg($_SESSION['errmsg']);
$htmlArr[err_msg]=$errMsg;
$perpageNum=5;
$recordstartNum=(($pageNO-1)*$perpageNum);
$dataMenuF=$dfnvar->StrctRflctArr($dataMenuR,'function_id');
$dataTableHead=$dbint->select("select * from wordbook where menu_id=".$navmenuID." order by id");
$sqlNum="select count(*) ct from ".$dataTmpC[0][tablestr].";";
$dataNum=$dbint->select($sqlNum);
if($recordstartNum>=$dataNum[0][ct]) $recordstartNum=$dataNum[0][ct]-$dataNum[0][ct]%$perpageNum;
$sql="select ";
$tableheadarray[Order]="序号";
$tableheadarray[OpInit]="操作选项";
foreach($dataTableHead as $val){
        $tableheadarray[$val[varname]]=$val[varvalue];
        $sql.=$val[varsql].",";
}
$sql=substr($sql,0,strlen($sql)-1)." from ".$dataTmpC[0][tablestr]." limit ".$recordstartNum.",".$perpageNum.";";
//$sqlNum="select count(*) ct from ".$dataTmpC[0][tablestr].";";
//$dataNum=$dbint->select($sqlNum);
//if($recordstartNum>=$dataNum[0][ct]) $recordstartNum=1;
$dataService=$dbint->select($sql);
//if($dataService){
//        foreach($dataMenuF as $key=>$val){
//                if($key>2){
//                        $functionarray[$key]=array($dataMenuF[$key][url],$dataMenuF[$key][name]);
//                }   
//        }   
//}
//$tiparray=array(array($dataMenuF[2][url],$dataMenuF[2][name]));
$tiparray=$modArr;
$tableheadHtml=$dfnvar->StrctTblMnStrt($tableheadarray,$tiparray,$dataService,$pageNO);
$tableendHtml=$dfnvar->StrctTblEnd('Mn');
$dsplbypgBar=$dfnvar->DsplByPg($pageNO,$dataNum[0][ct],$perpageNum);
$htmlArr[content_main]=$tableheadHtml.$tableendHtml.$dsplbypgBar;
$jsonArr=json_encode($htmlArr);
echo $jsonArr;
unset($htmlArr);
?>
