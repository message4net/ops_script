<?php session_start();
$navmenuID=$_POST[lid];
require_once('config.inc.php');
require_once IncludePath.'db.inc.php';
$dbint=new DBSql();
//$dataNavmenuID=$dbint->select("select * from link_js where id=".$navmenuID);
//require_once ModelPath.$dataNavmenuID[0][url];
require_once IncludePath.DfnInc;
//require_once IncludePath.VrfInc;
require_once IncludePath.TipsgenFnc;
//$strvrf=new strvrf();
$dfnvar=new dfnvar();
//require_once ModelPath.InfoshowMdl;
//$dataDealIptX=$dbint->select("select * from wordbook where remark like '*%' and function_id=0 and menu_id=".$dataMenuId[0][relation_id]." order by seq");
$dataDealIptX=$dbint->select("select * from wordbook where remark like '*%' and function_id=0 and menu_id=".$navmenuID." order by seq");
//$dataDealIptY=$dbint->select("select * from wordbook where remark not like '*%' and function_id=0 and menu_id=".$dataMenuId[0][relation_id]." order by seq");
$dataDealIptY=$dbint->select("select * from wordbook where remark not like '*%' and function_id=0 and menu_id=".$navmenuID." order by seq");
//选项类
//$dataDealOpt=$dbint->select("select * from wordbook where function_id>0 and function_id<3 and menu_id=".$dataMenuId[0][relation_id]." order by id");
$dataDealOpt=$dbint->select("select * from wordbook where function_id>0 and function_id<3 and menu_id=".$navmenuID." order by id");
//if(!empty($_GET[cid])){
if(!empty($_POST[cid])){
      $dataContent=$dbint->select('select * from '.$dealTable1.' where id='.$_GET[cid]);
      $dataMenuR[0][url].='&cid='.$_GET[cid];
}
foreach($dataDealIptX as $val){
      $tablearrayX[]=array($val[varvalue],$val[varname],$val[type],$dataContent[0][$val[varname]],$val[remark]);
}
//$dfnvar->StrctTblCrtStrt("请根据提示输入,带*必填",$tablearrayX,$dataMenuR[0][url],array(array('class','cntnt')));
$dfnvar->StrctTblCrtStrt("请根据提示输入,带*必填",$dataMenuR[0][url].'&pgnm='.$_GET[pgnm],array(array('class','cntnt')));
$dfnvar->StrctIpt($tablearrayX);
if($dataDealOpt){
      foreach($dataDealOpt as $val){
              if($val[function_id]==1){
                      $sql='select '.$val[colname].' from '.$val[tablename];
              }else{
                      $sql='select '.$val[colname].' from '.$val[tablename].' where relation_id='.$val[id];
              }
              $dataOpt=$dbint->select($sql);
              $keyarray=array_keys($dataOpt[0]);
              $dfnvar->StrctOptn($dataOpt,array($val[varvalue],$val[varname]),$dataContent[0][$val[varname]],array_keys($dataOpt[0]));
      }
}
foreach($dataDealIptY as $val){
        $tablearrayY[]=array($val[varvalue],$val[varname],$val[type],$dataContent[0][$val[varname]],$val[remark]);
}
//$dfnvar->StrctTblCrtStrt("请根据提示输入,带*必填",$tablearrayY,$dataMenuR[0][url],array(array('class','cntnt')));
$dfnvar->StrctIpt($tablearrayY);
$dfnvar->StrctTblEnd('Crt',$dataMenuId[0][name]);
?>
