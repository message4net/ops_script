<?php session_start();
require_once('/usr/local/http/opsmanage1/config.inc.php');
require_once IncludePath.DBInc;
require_once IncludePath.DfnInc;
require_once IncludePath.VrfInc;
require_once IncludePath.TipsgenFnc;
$dbint=new DBSql();
$strvrf=new strvrf();
$dfnvar=new dfnvar();
$navmenuID=$_POST[lid];
require_once ModelPath.InfoshowMdl;
?>
