<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<base href="<?php echo BsUrl; ?>">
<title>运维系统111111</title>
<link href="default.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="click.js"></script>
</head>
<body>
<div id="container">
