<?php
if($dataMenuId[0][relation_id]==0){
	$_SESSION[menuc]=$dataMenuR;
}
echo "<ul>";
foreach($_SESSION[menuc] as $val){
	echo "<li id='".$val[id]."'><a href=".$val[url].">".$val[name]."</a></li>";
}
echo "</ul>";
?>
