<?php
	$DBCon=array(
			"init"=>array(
					"dbhost"=>"",
					"dbuser"=>"",
					"dbpasswd"=>"",
					"dbname"=>""
			)
			
	);
?>