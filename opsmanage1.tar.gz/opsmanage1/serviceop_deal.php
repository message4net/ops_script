<?php session_start();
require_once('config.inc.php');
require_once IncludePath.'db.inc.php';
$opNameArr=json_decode($_POST[opname],true);
$dbint=new DBSql();
$dataOpDetail=$dbint->select('select * from op_service where service_id='.$opNameArr[0][id].' and op_op_id='.$_POST[opdetail]);
$returnArr=array($dataOpDetail,'zzz');
echo json_encode($returnArr);
//echo json_encode($dataOpDetail);
//echo '{"aaa":'.json_encode($dataOpDetail).'}';
?>
