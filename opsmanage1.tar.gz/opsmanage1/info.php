<?php
require_once IncludePath.'dfn.inc.php';
require_once IncludePath.'vrf.inc.php';
$strvrf=new strvrf();
$dfnvar=new dfnvar();
switch ($_GET[mid]){
case '5':
case '14':
case '16':
        $dealTable='op_service';
        $dealTable1='op_service';
        break;
case '4':
case '8':
case '9':
        $dealTable='service_info t1,server_info t2 where t1.host_id=t2.id';
        $dealTable1='service_info';
        break;
case '3':
case '22':
case '23':
        $dealTable='server_info';
        $dealTable1='server_info';
        break;
}
echo "<div><b><i>".$_SESSION[tips]."</i></b></div>";
$strvrf->PrntErrMsg($_SESSION['errmsg']);
//if($strvrf->StrNullVrf($_GET[pgnm])==0) $_GET[pgnm]=1;
if($dataMenuId[0][relation_id]>0&&$dataMenuId[0][function_id]==0){
//	if($strvrf->StrNullVrf($_GET[pgnm])==0) $_GET[pgnm]=1;
	$perpageNum=5;
//	$recordstartNum=(($_GET[pgnm]-1)*$perpageNum+1);
	$recordstartNum=(($_GET[pgnm]-1)*$perpageNum);
        $dataMenuF=$dfnvar->StrctRflctArr($dataMenuR,'function_id');
        $dataTableHead=$dbint->select("select * from wordbook where menu_id=".$_GET[mid]." order by id");
        $sql="select ";
        $tableheadarray[Order]="序号";
        $tableheadarray[OpInit]="操作选项";
        foreach($dataTableHead as $val){
                $tableheadarray[$val[varname]]=$val[varvalue];
                $sql.=$val[varsql].",";
        }
        $sql=substr($sql,0,strlen($sql)-1)." from ".$dealTable." limit ".$recordstartNum.",".$perpageNum.";";
        $sqlNum="select count(*) ct from ".$dealTable.";";
	$dataNum=$dbint->select($sqlNum);
        $dataService=$dbint->select($sql);
	if($dataService){
		foreach($dataMenuF as $key=>$val){
			if($key>2){
	        		$functionarray[$key]=array($dataMenuF[$key][url],$dataMenuF[$key][name]);
			}
		}
	}
	$tiparray=array(array($dataMenuF[2][url],$dataMenuF[2][name]));
	$dfnvar->StrctTblMnStrt("",$tableheadarray,$tiparray,$dataService,$functionarray,$_GET[pgnm]);
        $dfnvar->StrctTblEnd('Mn');
	$dsplbypgBar=$dfnvar->DsplByPg($_GET[pgnm],$dataNum[0][ct],$dataMenuId[0][url],$perpageNum,array(array('fnctn',$_GET[fnctn]),array('mid',$_GET[mid])));
	echo $dsplbypgBar;
}else{
	if($dataMenuId[0][relation_id]>0&&$dataMenuId[0][type]==0){
	        $dataDealIptX=$dbint->select("select * from wordbook where remark like '*%' and function_id=0 and menu_id=".$dataMenuId[0][relation_id]." order by seq");
	        $dataDealIptY=$dbint->select("select * from wordbook where remark not like '*%' and function_id=0 and menu_id=".$dataMenuId[0][relation_id]." order by seq");
		//选项类
	        $dataDealOpt=$dbint->select("select * from wordbook where function_id>0 and function_id<3 and menu_id=".$dataMenuId[0][relation_id]." order by id");
		if(!empty($_GET[cid])){
			$dataContent=$dbint->select('select * from '.$dealTable1.' where id='.$_GET[cid]);
			$dataMenuR[0][url].='&cid='.$_GET[cid];
		}
	        foreach($dataDealIptX as $val){
	                $tablearrayX[]=array($val[varvalue],$val[varname],$val[type],$dataContent[0][$val[varname]],$val[remark]);
        	}
//	        $dfnvar->StrctTblCrtStrt("请根据提示输入,带*必填",$tablearrayX,$dataMenuR[0][url],array(array('class','cntnt')));
	        $dfnvar->StrctTblCrtStrt("请根据提示输入,带*必填",$dataMenuR[0][url].'&pgnm='.$_GET[pgnm],array(array('class','cntnt')));
	        $dfnvar->StrctIpt($tablearrayX);
		if($dataDealOpt){
			foreach($dataDealOpt as $val){
				if($val[function_id]==1){
					$sql='select '.$val[colname].' from '.$val[tablename];
				}else{
					$sql='select '.$val[colname].' from '.$val[tablename].' where relation_id='.$val[id];
				}
				$dataOpt=$dbint->select($sql);
				$keyarray=array_keys($dataOpt[0]);
				$dfnvar->StrctOptn($dataOpt,array($val[varvalue],$val[varname]),$dataContent[0][$val[varname]],array_keys($dataOpt[0]));
			}
		}
	        foreach($dataDealIptY as $val){
	                $tablearrayY[]=array($val[varvalue],$val[varname],$val[type],$dataContent[0][$val[varname]],$val[remark]);
        	}
//	        $dfnvar->StrctTblCrtStrt("请根据提示输入,带*必填",$tablearrayY,$dataMenuR[0][url],array(array('class','cntnt')));
	        $dfnvar->StrctIpt($tablearrayY);
	        $dfnvar->StrctTblEnd('Crt',$dataMenuId[0][name]);
	}
}
?>
