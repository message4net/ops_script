<?php session_start();
require_once('config.inc.php');
require_once IncludePath.'db.inc.php';
require_once('head.php');
switch ($_GET[fnctn]){
	case "logout":
		require_once('logout.php');
		break;
	default:
		if($_SESSION[islogin]=="YES"){
			require_once('main.php');
		}else{
			require_once('login.php');
		}
	}
require_once('foot.php');
?>
